﻿namespace LocalNetworkFileShare
{
    partial class ServerControlMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServerControlMenu));
            richTextBox1 = new RichTextBox();
            button1 = new Button();
            button2 = new Button();
            checkBox1 = new CheckBox();
            panel1 = new Panel();
            richTextBox2 = new RichTextBox();
            label1 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            panel3 = new Panel();
            checkBox2 = new CheckBox();
            panel4 = new Panel();
            label11 = new Label();
            checkBox3 = new CheckBox();
            button4 = new Button();
            button3 = new Button();
            label6 = new Label();
            panel5 = new Panel();
            label13 = new Label();
            label7 = new Label();
            button5 = new Button();
            label8 = new Label();
            label9 = new Label();
            button6 = new Button();
            textBox1 = new TextBox();
            label10 = new Label();
            panel6 = new Panel();
            button7 = new Button();
            button8 = new Button();
            label12 = new Label();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // richTextBox1
            // 
            richTextBox1.BorderStyle = BorderStyle.FixedSingle;
            richTextBox1.Location = new Point(13, 712);
            richTextBox1.Margin = new Padding(3, 4, 3, 4);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.ScrollBars = RichTextBoxScrollBars.Vertical;
            richTextBox1.Size = new Size(511, 713);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            richTextBox1.MouseClick += richTextBox1_MouseClick;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(13, 652);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(168, 52);
            button1.TabIndex = 1;
            button1.Text = "Clear";
            button1.UseVisualStyleBackColor = true;
            button1.MouseClick += button1_MouseClick;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(189, 652);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(163, 51);
            button2.TabIndex = 2;
            button2.Text = "Save log";
            button2.UseVisualStyleBackColor = true;
            button2.MouseClick += button2_MouseClick;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Cursor = Cursors.Hand;
            checkBox1.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            checkBox1.Location = new Point(359, 659);
            checkBox1.Margin = new Padding(3, 4, 3, 4);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(143, 29);
            checkBox1.TabIndex = 3;
            checkBox1.Text = "Auto-saving";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.Visible = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(richTextBox2);
            panel1.Location = new Point(586, 712);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(527, 714);
            panel1.TabIndex = 4;
            // 
            // richTextBox2
            // 
            richTextBox2.Cursor = Cursors.Help;
            richTextBox2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            richTextBox2.Location = new Point(3, 3);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.ScrollBars = RichTextBoxScrollBars.Vertical;
            richTextBox2.Size = new Size(521, 708);
            richTextBox2.TabIndex = 0;
            richTextBox2.Text = "";
            richTextBox2.MouseClick += richTextBox2_MouseClick;
            richTextBox2.TextChanged += richTextBox2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.Location = new Point(599, 660);
            label1.Name = "label1";
            label1.Size = new Size(186, 25);
            label1.TabIndex = 5;
            label1.Text = "Connected devices:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.Location = new Point(1190, 15);
            label2.Name = "label2";
            label2.Size = new Size(128, 25);
            label2.TabIndex = 6;
            label2.Text = "Connections:";
            label2.Click += label2_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Location = new Point(1176, 66);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(604, 288);
            panel2.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.Location = new Point(1125, 68);
            label3.Name = "label3";
            label3.Size = new Size(40, 22);
            label3.TabIndex = 8;
            label3.Text = "100";
            label3.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.Location = new Point(1147, 326);
            label4.Name = "label4";
            label4.Size = new Size(20, 22);
            label4.TabIndex = 9;
            label4.Text = "0";
            label4.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label5.Location = new Point(1136, 196);
            label5.Name = "label5";
            label5.Size = new Size(30, 22);
            label5.TabIndex = 10;
            label5.Text = "50";
            label5.Visible = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(checkBox2);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(label6);
            panel3.Location = new Point(1381, 715);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(560, 622);
            panel3.TabIndex = 11;
            panel3.Visible = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Cursor = Cursors.Hand;
            checkBox2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            checkBox2.Location = new Point(21, 82);
            checkBox2.Margin = new Padding(3, 4, 3, 4);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(232, 33);
            checkBox2.TabIndex = 2;
            checkBox2.Text = "Anti-DDoS system";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            panel4.BackColor = Color.LightCoral;
            panel4.Controls.Add(label11);
            panel4.Controls.Add(checkBox3);
            panel4.Controls.Add(button4);
            panel4.Controls.Add(button3);
            panel4.Location = new Point(3, 205);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(553, 414);
            panel4.TabIndex = 1;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Impact", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label11.ForeColor = Color.White;
            label11.Location = new Point(9, 14);
            label11.Name = "label11";
            label11.Size = new Size(254, 44);
            label11.TabIndex = 4;
            label11.Text = "Dangerous zone";
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Cursor = Cursors.Hand;
            checkBox3.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            checkBox3.Location = new Point(311, 32);
            checkBox3.Margin = new Padding(3, 4, 3, 4);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(99, 29);
            checkBox3.TabIndex = 3;
            checkBox3.Text = "Enable";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Cursor = Cursors.Hand;
            button4.FlatAppearance.BorderColor = Color.Red;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button4.Location = new Point(18, 179);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(459, 68);
            button4.TabIndex = 2;
            button4.Text = "Stop server";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.BorderColor = Color.Red;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button3.Location = new Point(18, 112);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(459, 58);
            button3.TabIndex = 1;
            button3.Text = "Disconnect all connections";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label6.Location = new Point(16, 15);
            label6.Name = "label6";
            label6.Size = new Size(99, 29);
            label6.TabIndex = 0;
            label6.Text = "Security";
            // 
            // panel5
            // 
            panel5.BackColor = Color.White;
            panel5.Controls.Add(label13);
            panel5.Controls.Add(label7);
            panel5.Location = new Point(586, 15);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(527, 622);
            panel5.TabIndex = 12;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label13.Location = new Point(13, 73);
            label13.Name = "label13";
            label13.Size = new Size(0, 38);
            label13.TabIndex = 1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label7.Location = new Point(13, 15);
            label7.Name = "label7";
            label7.Size = new Size(143, 29);
            label7.TabIndex = 0;
            label7.Text = "Storage info";
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button5.Location = new Point(13, 15);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(168, 74);
            button5.TabIndex = 13;
            button5.Text = "Start";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            button5.MouseClick += button5_MouseClick;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label8.Location = new Point(188, 15);
            label8.Name = "label8";
            label8.Size = new Size(47, 29);
            label8.TabIndex = 14;
            label8.Text = "IP: ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label9.Location = new Point(188, 68);
            label9.Name = "label9";
            label9.Size = new Size(63, 29);
            label9.TabIndex = 15;
            label9.Text = "Port:";
            // 
            // button6
            // 
            button6.Cursor = Cursors.Hand;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button6.Location = new Point(13, 160);
            button6.Margin = new Padding(3, 4, 3, 4);
            button6.Name = "button6";
            button6.Size = new Size(386, 71);
            button6.TabIndex = 16;
            button6.Text = "Server options";
            button6.UseVisualStyleBackColor = true;
            button6.MouseClick += button6_MouseClick;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox1.Location = new Point(13, 316);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(565, 35);
            textBox1.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label10.Location = new Point(13, 261);
            label10.Name = "label10";
            label10.Size = new Size(109, 29);
            label10.TabIndex = 18;
            label10.Text = "Console:";
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Location = new Point(13, 425);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(551, 212);
            panel6.TabIndex = 19;
            // 
            // button7
            // 
            button7.Cursor = Cursors.Hand;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button7.Location = new Point(13, 368);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(209, 50);
            button7.TabIndex = 20;
            button7.Text = "Send";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            button7.MouseClick += button7_MouseClick;
            // 
            // button8
            // 
            button8.Cursor = Cursors.Hand;
            button8.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button8.Location = new Point(1625, 361);
            button8.Name = "button8";
            button8.Size = new Size(152, 48);
            button8.TabIndex = 21;
            button8.Text = "Clear";
            button8.UseVisualStyleBackColor = true;
            button8.MouseClick += button8_MouseClick;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label12.Location = new Point(1176, 371);
            label12.Name = "label12";
            label12.Size = new Size(23, 28);
            label12.TabIndex = 22;
            label12.Text = "0";
            // 
            // ServerControlMenu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1785, 1441);
            Controls.Add(label12);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(panel6);
            Controls.Add(label10);
            Controls.Add(textBox1);
            Controls.Add(button6);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(button5);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(panel2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(checkBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(richTextBox1);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "ServerControlMenu";
            Text = "Server Control Menu";
            FormClosing += ServerControlMenu_FormClosing;
            Load += ServerControlMenu_Load;
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label11;
        private Button button8;
        private RichTextBox richTextBox2;
        private Label label12;
        private Label label13;
    }
}