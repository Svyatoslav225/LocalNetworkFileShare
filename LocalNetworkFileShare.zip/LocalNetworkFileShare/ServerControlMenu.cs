﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LocalNetworkFileShare
{
    public partial class ServerControlMenu : Form
    {
        public ServerControlMenu()
        {
            InitializeComponent();
        }

        private void ServerControlMenu_Load(object sender, EventArgs e)
        {

        }
    }
}
