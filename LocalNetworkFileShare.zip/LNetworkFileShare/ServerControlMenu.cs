﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using LNetworkFileShare;

namespace LocalNetworkFileShare
{
    public partial class ServerControlMenu : Form
    {
        Socket MainListener;
        public ServerControlMenu()
        {
            InitializeComponent();
        }
        private void SetCurrentOptions()
        {
            try
            {
                string mainConfigFile = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg");
                string[] linesSpl = mainConfigFile.Split('\n');
                int index = 0;
                foreach (string line in linesSpl)
                {
                    string[] words = line.Split(' ');

                    if (words[0] == "Theme_UIstyle")
                    {
                        switch (words[1])
                        {
                            case "0":
                                label8.ForeColor = Color.Black;
                                label9.ForeColor = Color.Black;
                                label10.ForeColor = Color.Black;
                                label7.ForeColor = Color.Black;
                                label6.ForeColor = Color.Black;
                                label5.ForeColor = Color.Black;
                                label4.ForeColor = Color.Black;
                                label3.ForeColor = Color.Black;
                                label2.ForeColor = Color.Black;
                                label1.ForeColor = Color.Black;
                                label11.ForeColor = Color.White;
                                button6.BackColor = SystemColors.Window;
                                button6.ForeColor = Color.Black;
                                button5.BackColor = SystemColors.Window;
                                button5.ForeColor = Color.Black;
                                button7.ForeColor = Color.Black;
                                button7.BackColor = SystemColors.Window;
                                button5.ForeColor = Color.Black;
                                button5.BackColor = SystemColors.Window;
                                button4.ForeColor = Color.Black;
                                button4.BackColor = SystemColors.Window;
                                button3.ForeColor = Color.Black;
                                button3.BackColor = SystemColors.Window;
                                button2.ForeColor = Color.Black;
                                button2.BackColor = SystemColors.Window;
                                button1.ForeColor = Color.Black;
                                button1.BackColor = SystemColors.Window;
                                textBox1.ForeColor = Color.Black;
                                textBox1.BackColor = SystemColors.Window;
                                richTextBox1.ForeColor = Color.Black;
                                richTextBox1.BackColor = SystemColors.Window;
                                panel1.BackColor = Color.White;
                                panel2.BackColor = Color.White;
                                panel3.BackColor = Color.White;
                                panel4.BackColor = Color.LightCoral;
                                panel5.BackColor = Color.White;
                                panel6.BackColor = Color.White;
                                checkBox1.ForeColor = Color.Black;
                                checkBox2.ForeColor = Color.Black;
                                checkBox3.ForeColor = Color.White;
                                this.BackColor = SystemColors.Control;
                                break;
                            case "1":
                                label8.ForeColor = Color.White;
                                label9.ForeColor = Color.White;
                                label10.ForeColor = Color.White;
                                label7.ForeColor = Color.White;
                                label6.ForeColor = Color.White;
                                label5.ForeColor = Color.White;
                                label4.ForeColor = Color.White;
                                label3.ForeColor = Color.White;
                                label2.ForeColor = Color.White;
                                label11.ForeColor = Color.White;
                                label1.ForeColor = Color.White;
                                button6.BackColor = Color.FromArgb(54, 54, 54);
                                button6.ForeColor = Color.White;
                                button5.BackColor = Color.FromArgb(54, 54, 54);
                                button5.ForeColor = Color.White;
                                button7.ForeColor = Color.White;
                                button7.BackColor = Color.FromArgb(54, 54, 54);
                                button5.ForeColor = Color.White;
                                button5.BackColor = Color.FromArgb(54, 54, 54);
                                button4.ForeColor = Color.White;
                                button4.BackColor = Color.FromArgb(54, 54, 54);
                                button3.ForeColor = Color.White;
                                button3.BackColor = Color.FromArgb(54, 54, 54);
                                button2.ForeColor = Color.White;
                                button2.BackColor = Color.FromArgb(54, 54, 54);
                                button1.ForeColor = Color.White;
                                button1.BackColor = Color.FromArgb(54, 54, 54);
                                textBox1.ForeColor = Color.White;
                                textBox1.BackColor = Color.FromArgb(54, 54, 54);
                                richTextBox1.ForeColor = Color.White;
                                richTextBox1.BackColor = Color.FromArgb(44, 44, 44);
                                panel1.BackColor = Color.FromArgb(44, 44, 44);
                                panel2.BackColor = Color.FromArgb(44, 44, 44);
                                panel3.BackColor = Color.FromArgb(44, 44, 44);
                                panel4.BackColor = Color.Maroon;
                                panel5.BackColor = Color.FromArgb(44, 44, 44);
                                panel6.BackColor = Color.FromArgb(44, 44, 44);
                                checkBox1.ForeColor = Color.White;
                                checkBox2.ForeColor = Color.White;
                                checkBox3.ForeColor = Color.White;
                                this.BackColor = Color.FromArgb(34, 34, 34);
                                break;
                            case "2":

                                break;
                        }
                    }
                    else if (words[0] == "UIText_language")
                    {
                        switch (words[1])
                        {
                            case "0":
                                label1.Text = "Connected devices:";
                                label2.Text = "Connections:";
                                label6.Text = "Security";
                                label7.Text = "Storage info";
                                label8.Text = "IP: ";
                                label9.Text = "Port: ";
                                label10.Text = "Console";
                                label11.Text = "Dangerous zone";
                                button1.Text = "Clear";
                                button2.Text = "Save";
                                button3.Text = "Delete all connections";
                                button4.Text = "Pause server";
                                button5.Text = "Start";
                                button6.Text = "Server options";
                                button7.Text = "Send";
                                checkBox1.Text = "Auto-saving";
                                checkBox2.Text = "Anti-DDoS system";
                                checkBox3.Text = "Enable";
                                checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                                break;
                            case "1":
                                label1.Text = "Подключённые устройства:";
                                label2.Text = "Подключённые сокеты:";
                                label6.Text = "Безопасность";
                                label7.Text = "Информация о хранилище";
                                label8.Text = "IP: ";
                                label9.Text = "Port: ";
                                label10.Text = "Консоль";
                                label11.Text = "Опасная зона";
                                button1.Text = "Очистить";
                                button2.Text = "Сохранить";
                                button3.Text = "Разорвать все подключения";
                                button4.Text = "Временно остановить работу сервера";
                                button5.Text = "Начать";
                                button6.Text = "Настройки сервера";
                                button7.Text = "Отправить";
                                checkBox1.Text = "Авто-сохранение";
                                checkBox2.Text = "Анти-DDoS система";
                                checkBox3.Text = "Включить";
                                checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                                break;
                            case "2":
                                label1.Text = "Verbundene Geräte:";
                                label2.Text = "Netzwerkverbindungen:";
                                label6.Text = "Sicherheit";
                                label7.Text = "Lagerinfo";
                                label8.Text = "IP: ";
                                label9.Text = "Port: ";
                                label10.Text = "Konsole";
                                label11.Text = "Gefährliche Zone";
                                button1.Text = "Klar";
                                button2.Text = "Speichern";
                                button3.Text = "Alle Verbindungen löschen";
                                button4.Text = "Server pausieren";
                                button5.Text = "Beginnen";
                                button6.Text = "Serveroptionen";
                                button7.Text = "Senden";
                                checkBox1.Text = "Automatisches Speichern";
                                checkBox2.Text = "Anti-DDoS system";
                                checkBox3.Text = "Aktivieren";
                                checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                                break;
                            case "3":
                                label1.Text = "连接设备:";
                                label2.Text = "联系:";
                                label6.Text = "保安";
                                label7.Text = "储存资料";
                                label8.Text = "IP: ";
                                label9.Text = "Port: ";
                                label10.Text = "控制台";
                                label11.Text = "危险地带";
                                button1.Text = "清楚";
                                button2.Text = "储蓄";
                                button3.Text = "删除所有连接";
                                button4.Text = "暂停服务器";
                                button5.Text = "开始";
                                button6.Text = "服务器选项";
                                button7.Text = "发送";
                                checkBox1.Text = "自动储蓄";
                                checkBox2.Text = "DDoS系统";
                                checkBox3.Text = "启用";
                                checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                                break;
                        }
                    }
                    else if (words[0] == "Device_name")
                    {
                        string[] spl = line.Split(' ');
                        string res = "";
                        for (int i = 0; i < spl.Length; i++)
                        {
                            if (i != 0)
                            {
                                res += spl[i] + " ";
                            }
                        }
                        // textBox1.Text = res;
                    }
                }
            }
            catch (Exception exc)
            {
                File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg", ""); // creating file
                SetCurrentOptions(); // restarting function
            }
        }
        private void ServerControlMenu_Load(object sender, EventArgs e)
        {
            SetCurrentOptions();
        }

        protected internal async Task MainListening(int Port)
        {
            IPHostEntry entry = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress addr = entry.AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork);
            IPEndPoint endP = new IPEndPoint(addr, Port);
            MainListener = new Socket(addr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            MainListener.Bind(endP);
            MainListener.Listen(Port);

            label8.Text += addr.ToString();
            label9.Text += endP.Port;
            while (true)
            {
                var handler = await MainListener.AcceptAsync();
                byte[] buffer = new byte[2048];
                int received = await handler.ReceiveAsync(buffer, 0);
                string responce = Encoding.UTF8.GetString(buffer, 0, received);

                string[] DoublePointSplitted = responce.Split(":");
                switch (DoublePointSplitted[0])
                {
                    case "":

                        break;
                }

            }
        }
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button5_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void button6_MouseClick(object sender, MouseEventArgs e)
        {
            ServerOptions options = new ServerOptions();
            options.Show();
        }
    }
}
