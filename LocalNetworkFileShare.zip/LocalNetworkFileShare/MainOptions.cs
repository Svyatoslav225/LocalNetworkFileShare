﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LocalNetworkFileShare
{
    public partial class MainOptions : Form
    {
        private const int StPosY = 12;
        public MainMenu parentCl;
        public MainOptions()
        {
            InitializeComponent();
            radioButton1.Parent = panel1;
            radioButton2.Parent = panel1;
            radioButton3.Parent = panel1;
            SetCurrentOptions();
        }
        
        private void SetCurrentOptions()
        {
            string mainConfigFile = File.ReadAllText(@"D:\mainConfig.cfg");
            string[] linesSpl = mainConfigFile.Split('\n');
            int index = 0;
            foreach (string line in linesSpl)
            {
                string[] words = line.Split(' ');

                if (words[0] == "Theme_style")
                {
                    switch (words[1])
                    {
                        case "0":
                            radioButton2.Checked = true;
                            panel1.BackColor = SystemColors.Control;
                            button1.BackColor = Color.White;
                            button1.ForeColor = Color.Black;
                            label1.ForeColor = Color.Black;
                            radioButton1.ForeColor = Color.Black;
                            radioButton2.ForeColor = Color.Black;
                            radioButton3.ForeColor = Color.Black;
                            this.BackColor = SystemColors.Control;
                            break;
                        case "1":
                            radioButton1.Checked = true;
                            panel1.BackColor = Color.FromArgb(34, 34, 34);
                            button1.BackColor = Color.FromArgb(54, 54, 54);
                            button1.ForeColor = Color.White;
                            label1.ForeColor = Color.White;
                            radioButton1.ForeColor = Color.White;
                            radioButton2.ForeColor = Color.White;
                            radioButton3.ForeColor = Color.White;
                            this.BackColor = Color.FromArgb(34,34,34);
                            break;
                        case "2":
                            radioButton3.Checked = true;
                            break;
                    }
                }
            }
        }
        private void UpdateOptionsFile()
        {
            string resFile = "";

            resFile += "Theme_style ";
            if (radioButton1.Checked == true)
            {
                resFile += "1";
            }
            else if (radioButton2.Checked == true)
            {
                resFile += "0";
            }
            else if (radioButton3.Checked == true)
            {
                resFile += "2";
            }

                File.WriteAllText(@"D:\mainConfig.cfg", resFile);
        }
        private void MainOptions_Load(object sender, EventArgs e)
        {
            
        }

        private void vScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            panel1.Location = new Point(12,StPosY - (vScrollBar1.Value * 3));
            //button1.Location = new Point(756, 3);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
          //  radioButton2.Checked = false;
          //  radioButton3.Checked = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
          //  radioButton1.Checked = false;
          //  radioButton3.Checked = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
          //  radioButton2.Checked = false;
          //  radioButton1.Checked = false;
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            button1.Text = "Saving ...";
            UpdateOptionsFile();
            SetCurrentOptions();
            parentCl.UpdateStyleDel += parentCl.SetCurrentOptions;
            parentCl.UpdateStyleTrg();
            button1.Text = "Save";
        }
    }
}
