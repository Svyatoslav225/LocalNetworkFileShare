﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LocalNetworkFileShare
{
    public partial class MainMenu : Form
    {
        public event Action UpdateStyleDel;
        public MainMenu()
        {
            InitializeComponent();
            button1.Parent = panel1;
            button2.Parent = panel1;
            button3.Parent = panel1;
            SetCurrentOptions();
        }
        public void SetCurrentOptions() // Updating UI style
        {
            try
            {
                string mainConfigFile = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg"); // can throw exception
                string[] linesSpl = mainConfigFile.Split('\n');
                int index = 0;
                foreach (string line in linesSpl)
                {
                    string[] words = line.Split(' ');

                    if (words[0] == "Theme_UIstyle")
                    {
                        switch (words[1])
                        {
                            case "0":
                                panel1.BackColor = Color.FromArgb(224, 224, 224);
                                button1.BackColor = Color.White;
                                button1.ForeColor = Color.Black;
                                button2.BackColor = Color.White;
                                button2.ForeColor = Color.Black;
                                button3.BackColor = Color.White;
                                button3.ForeColor = Color.Black;
                                label1.ForeColor = Color.Black;
                                this.BackColor = SystemColors.Control;
                                label3.ForeColor = Color.Black;
                                break;
                            case "1":
                                panel1.BackColor = Color.FromArgb(44, 44, 44);
                                button1.BackColor = Color.FromArgb(54, 54, 54);
                                button2.BackColor = Color.FromArgb(54, 54, 54);
                                button3.BackColor = Color.FromArgb(54, 54, 54);
                                button1.ForeColor = Color.White;
                                button2.ForeColor = Color.White;
                                button3.ForeColor = Color.White;
                                label1.ForeColor = Color.White;
                                this.BackColor = Color.FromArgb(34, 34, 34);
                                label3.ForeColor = Color.White;
                                break;
                            case "2":
                                break;
                        }
                    }
                }
            }catch(Exception exc)
            {
                File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg",""); // creating file
                SetCurrentOptions(); // restarting method
            }
        }
        private void MainMenu_Load(object sender, EventArgs e)
        {

        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void button2_MouseClick(object sender, MouseEventArgs e)
        {

        }
        public void UpdateStyleTrg() // trigger for start updating UI style
        {
            UpdateStyleDel?.Invoke();
        }
        private void button3_MouseClick(object sender, MouseEventArgs e)
        {
            MainOptions opts = new MainOptions();
            opts.parentCl= this;
            opts.Show();
            
        }

        private void label2_MouseClick(object sender, MouseEventArgs e)
        {
            MITLicense licenseForm = new MITLicense();
            licenseForm.Show();
        }
    }
}
