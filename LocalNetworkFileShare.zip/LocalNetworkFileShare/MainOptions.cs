﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LocalNetworkFileShare
{
    public partial class MainOptions : Form
    {
        private const int StPosY = 12; // start position Y
        public MainMenu parentCl;
        public MainOptions()
        {
            InitializeComponent();
            radioButton1.Parent = panel1;
            radioButton2.Parent = panel1;
            radioButton3.Parent = panel1;
            checkBox1.Parent = panel1;
            checkBox2.Parent = panel1;
            checkBox3.Parent = panel1;
            checkBox5.Parent = panel1;
            SetCurrentOptions();
        }
        
        private void SetCurrentOptions()
        {
            try
            {
                string mainConfigFile = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg"); // if file doesn't exists will throw exception
                string[] linesSpl = mainConfigFile.Split('\n');
                int index = 0;
                foreach (string line in linesSpl)
                {
                    string[] words = line.Split(' ');

                    if (words[0] == "Theme_UIstyle")
                    {
                        switch (words[1])
                        {
                            case "0":
                                radioButton2.Checked = true;
                                panel1.BackColor = SystemColors.Control;
                                button1.BackColor = Color.White;
                                button1.ForeColor = Color.Black;
                                label1.ForeColor = Color.Black;
                                radioButton1.ForeColor = Color.Black;
                                radioButton2.ForeColor = Color.Black;
                                radioButton3.ForeColor = Color.Black;
                                this.BackColor = SystemColors.Control;
                                label2.ForeColor = Color.Black;
                                checkBox1.ForeColor = Color.Black;
                                checkBox2.ForeColor = Color.Black;
                                checkBox3.ForeColor = Color.Black;
                                checkBox5.ForeColor = Color.Black;
                                break;
                            case "1":
                                radioButton1.Checked = true;
                                panel1.BackColor = Color.FromArgb(34, 34, 34);
                                button1.BackColor = Color.FromArgb(54, 54, 54);
                                button1.ForeColor = Color.White;
                                label1.ForeColor = Color.White;
                                radioButton1.ForeColor = Color.White;
                                radioButton2.ForeColor = Color.White;
                                radioButton3.ForeColor = Color.White;
                                this.BackColor = Color.FromArgb(34, 34, 34);
                                label2.ForeColor = Color.White;
                                checkBox1.ForeColor = Color.White;
                                checkBox2.ForeColor = Color.White;
                                checkBox3.ForeColor = Color.White;
                                checkBox5.ForeColor = Color.White;
                                break;
                            case "2":
                                radioButton3.Checked = true;
                                break;
                        }
                    }else if (words[0] == "UIText_language")
                    {
                        switch (words[1])
                        {
                            case "0":
                                checkBox1.Checked = true;
                                checkBox1.Text = "English";
                                checkBox2.Text = "Русский (russian)";
                                checkBox3.Text = "Deutsch (german)";
                                checkBox5.Text = "中文 (chineese)";
                                label1.Text = "Theme";
                                label2.Text = "Language";
                                radioButton1.Text = "Dark";
                                radioButton2.Text = "Light";
                                radioButton3.Text = "Win98";
                                button1.Text = "Save";
                                break;
                            case "1":
                                checkBox2.Checked = true;
                                checkBox1.Text = "English (Английский)";
                                checkBox2.Text = "Русский";
                                checkBox3.Text = "Deutsch (Немецкий)";
                                checkBox5.Text = "中文 (Китайский)";
                                label1.Text = "Тема";
                                label2.Text = "Язык";
                                radioButton1.Text = "Тёмная";
                                radioButton2.Text = "Светлая";
                                radioButton3.Text = "Вин98";
                                button1.Text = "Сохранить";
                                break;
                        }
                    }
                }
            }catch(Exception exc)
            {
                File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg",""); // creating file
                SetCurrentOptions(); // restarting function
            }
        }
        private void UpdateOptionsFile() 
        {
            string resFile = "";

            resFile += "Theme_UIstyle ";
            if (radioButton1.Checked == true)
            {
                resFile += "1";
            }
            else if (radioButton2.Checked == true)
            {
                resFile += "0";
            }
            else if (radioButton3.Checked == true)
            {
                resFile += "2";
            }
            resFile += "\n";
            resFile += "UIText_language ";
            if (checkBox1.Checked == true)
            {
                resFile += "0";
            }else if (checkBox2.Checked == true)
            {
                resFile += "1";
            }else if (checkBox3.Checked == true)
            {
                resFile += "2";
            }else if (checkBox5.Checked == true)
            {
                resFile += "3";
            }
            resFile += "\n";
            File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + @"\mainConfig.cfg", resFile);
        }
        private void MainOptions_Load(object sender, EventArgs e)
        {
            
        }

        private void vScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            panel1.Location = new Point(12,StPosY - (vScrollBar1.Value * 3)); // scrolling
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            button1.Text = "Saving ...";
            UpdateOptionsFile();
            SetCurrentOptions();
            parentCl.UpdateStyleDel += parentCl.SetCurrentOptions;
            parentCl.UpdateStyleTrg();
            button1.Text = "Save";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox1_MouseClick(object sender, MouseEventArgs e)
        {
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox5.Checked = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox2_MouseClick(object sender, MouseEventArgs e)
        {
            checkBox1.Checked = false;
            checkBox3.Checked = false;
            checkBox5.Checked = false;
        }

        private void checkBox3_MouseClick(object sender, MouseEventArgs e)
        {
            checkBox2.Checked = false;
            checkBox1.Checked = false;
            checkBox5.Checked = false;
        }

        private void checkBox5_MouseClick(object sender, MouseEventArgs e)
        {
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox1.Checked = false;
        }
    }
}
